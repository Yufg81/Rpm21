﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using UrLabrity;
namespace UrTest
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void TestMethod1()
        {
            double n = double.NaN, m = double.NaN;
            string message = "Прямая совпадает с прямой, ответ:";
            double n_actual, m_actual, D_actual;
            string message_actual;

            Urclass.UR(0, 0, 0, out D_actual, out n_actual, out m_actual, out
                message_actual);
        }
    }
}
