﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace UrLabrity
{
    public class Urclass
    {
        public static void UR (double a, double b, double c, out double D, out double n, out double m, out string message)
        {
            D = n = m = double.NaN;
            if(a==0)
            {
                LineUr(b, c, n, out message);
                m = double.NaN;
                D = double.NaN;
            }
            else
            {
                D = b * b - 4 * a * c;
                if(D>0)
                {
                    n = (-b + Math.Sqrt(D)) / (2 * a);
                    m = ( b + Math.Sqrt(D)) / (2 * a);
                    message = "Дискриминант > 0, т.е. 2 корня";
                }
                else if(D==0){
                    n = -b / 2 / a;
                    m = double.NaN;
                    message = "Дискрименант < 0, т.е. 1 корень";
                }
            }
        }
        public static void LineUr(double k, double b, double x, out string message)
        {
            if(k==0)
            {
                x = double.NaN;
                if (b == 0) message = "Прямая совпадает, ответ:";
                else message = "Нет решений";
            }
        }
    }
}
